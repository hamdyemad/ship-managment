{{-- @extends('Dashboard.app')

@section('title')



@section('page_name')


@section('pages')

@endsection

@section('css')

@endsection

@section('content')
<form action="ViewPages" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="container">
        <div class="row">
            <label for="from" class="col-form-label">From</label>
            <div class="col-md-2">
                <input type="date" class="form-control input-sm" id="from" name="from">
            </div>
            <label for="from" class="col-form-label">To</label>
            <div class="col-md-2">
                <input type="date" class="form-control input-sm" id="to" name="to">
            </div>

            <div class="col-md-4">
                <button type="submit" class="btn btn-primary btn-sm" name="search">Search</button>
                <button type="submit" class="btn btn-secondary btn-sm" name="exportPDF">export PDF</button>
                <button type="submit" class="btn btn-success btn-sm" name="exportExcel">export Excel</button>

            </div>
        </div>
    </div>
</form>
@endsection

@section('js')

@endsection --}}
