@extends('Dashboard.app')

@section('title')



@section('page_name')


@section('pages')

@endsection

@section('css')

@endsection

@section('content')

@endsection

@section('js')

@endsection
