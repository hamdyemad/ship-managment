<?php $__env->startSection('title',__('site.add')); ?>

<?php $__env->startSection('page_name',__('site.shipment')); ?>


<?php $__env->startSection('pages'); ?>

<ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="<?php echo e(route('app')); ?>" class="text-muted text-hover-primary"><?php echo e(__('site.home')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="" class="text-muted text-hover-primary"><?php echo e(__('site.user')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="<?php echo e(route('shipment.index')); ?>" class="text-muted text-hover-primary"><?php echo e(__('site.shipment')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->

    <li class="breadcrumb-item text-muted">
        <a href="" class="text-muted text-hover-primary"><?php echo e(__('site.create')); ?></a>
    </li>
    <!--end::Item-->
</ul>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card mb-5 mb-xl-10">
    <!--begin::Card header-->
    <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
        data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
        <!--begin::Card title-->
        <div class="card-title m-0">
            <h3 class="fw-bolder m-0"><?php echo e(__('site.shipment')); ?></h3>
        </div>
        <!--end::Card title-->
    </div>
    <!--begin::Card header-->

    <!--begin::Content-->
    <div id="kt_account_profile_details" class="collapse show">
        <!--begin::Form-->
        <form id="kt_account_profile_details_form" class="form">
            <?php echo csrf_field(); ?>
            <!--begin::Card body-->
            <div class="card-body border-top p-9">


                <!--begin::shipment && business-->
                <div class="row mb-6">

                    <!--begin::Col-->
                    <div class="col-lg-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::shipment type-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.shipment_type')); ?></label>
                                <select name="shipment_type" id="shipment_type" data-placeholder="date_period"
                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0">
                                    <option value="" disabled selected>Select one ..
                                    </option>
                                    <option value="forward">Forward </option>
                                    <option value="exchange">exchange </option>
                                    <option value="cash_collection">cash collection </option>

                                </select>
                            </div>
                            <!--end::shipment type-->

                            <!--begin::Col-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.business')); ?></label>
                                <input type="text" id="business" name="business"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::shipment && business-->

                <div class="d-flex flex-stack fs-4 py-3">
                    <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="" role="button"
                        aria-expanded="" aria-controls="kt_user_view_details">
                        <?php echo e(__('site.receiver')); ?>

                        <span class="ms-2 rotate-180">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                            <span class="svg-icon svg-icon-3">

                            </span>
                            <!--end::Svg Icon-->
                        </span>
                    </div>

                </div>

                <!--begin::name && phone-->
                <div class="row mb-6">

                    <!--begin::Col-->
                    <div class="col-lg-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::receiver name-->
                            <div class="col-lg-6 fv-row">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.name')); ?></label>
                                <input type="text" id="receiver_name" name="receiver_name"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::receiver name-->

                            <!--begin::phone-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.phone')); ?></label>
                                <input type="text" id="receiver_phone" name="receiver_phone"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::phone-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::name && phone-->

                <!--begin::address-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        
                        <input type="text" id="address" name="address"
                            class="form-control form-control-lg form-control-solid">
                        <label for="address" class="col-lg-4 col-form-label fw-bold fs-6">address</label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::address-->

                <!--begin::city && area-->
                <div class="row">

                    <!--begin::city-->
                    <div class="col-lg-6 fv-row fv-plugins-icon-container">
                        <div class="mb-5">
                            <select data-dependent="area" name="city" id="city" aria-label="Select a Timezone"
                                data-control="select2" data-placeholder="date_period"
                                class="form-select form-select-sm form-select-solid dynamic">
                                <option value="" disabled selected>City
                                </option>
                                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option id="cityid" value="<?php echo e($city->id); ?>">
                                    <?php echo e($city->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div><br><br>
                    <!--end::city-->

                    <!--begin::area-->
                    <div class="col-lg-6 fv-row fv-plugins-icon-container">
                        <div class="mb-5">
                            <select name="area" id="area" aria-label="Select a Timezone" data-control="select2"
                                data-placeholder="date_period"
                                class="form-select form-select-sm form-select-solid dynamic">
                                <option value="" disabled selected>
                                </option>

                                
                            </select>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </div>
                    <!--end::area-->

                </div>
                <!--end::city && area-->

                <div class="d-flex flex-stack fs-4 py-3">
                    <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="" role="button"
                        aria-expanded="" aria-controls="kt_user_view_details">
                        <?php echo e(__('site.package')); ?>

                        <span class="ms-2 rotate-180">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                            <span class="svg-icon svg-icon-3">

                            </span>
                            <!--end::Svg Icon-->
                        </span>
                    </div>

                </div>

                <!--begin::package-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <textarea class="form-control form-control-lg form-control-solid" name="package" id="package"
                            style="height: 100px"></textarea>
                        <label for="package"><?php echo e(__('site.package')); ?></label>

                    </div>
                    <!--end::Col-->
                </div>
                <!--end::package-->

                <!--begin::price-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <input type="number" id="price" name="price"
                            class="form-control form-control-lg form-control-solid">
                        <label for="price" class="col-lg-4 col-form-label fw-bold fs-6"><?php echo e(__('site.price')); ?></label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::price-->

                <!--begin::note-->
                <div class="row mb-8">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <textarea class="form-control form-control-lg form-control-solid" name="note" id="note"
                            style="height: 100px"></textarea>
                        <label for="note"><?php echo e(__('site.note')); ?></label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::note-->

            </div>
            <!--end::Card body-->

            <!--begin::Actions-->
            <div class="card-footer d-flex justify-content-end py-6 px-9">
                <button type="button" onclick="addshipment()" class="btn btn-primary"
                    id="kt_account_profile_details_submit">
                    <?php echo e(__('site.add')); ?>

                </button>
            </div>
            <!--end::Actions-->
        </form>
        <!--end::Form-->
    </div>
    <!--end::Content-->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    //show city and his area in select tag
        $(document).ready(function(){

            $('.dynamic').change(function(){
                if($(this).val() != '')
                {
                var select = $(this).attr("id");
                var value = $(this).val();
                var dependent = $(this).data('dependent');
                var _token = $('input[name="_token"]').val();
                $.ajax({
                url:"<?php echo e(route('dynamicdependent.fetch')); ?>",
                method:"POST",
                data:{select:select, value:value, _token:_token, dependent:dependent},
                success:function(result)
                {
                $('#'+ dependent).html(result);
                }

                })
                }
            });

                $('#city').change(function(){
                $('#area').val('');

                });

        });

        //add shipment details
        function addshipment() {
            axios.post('/dashboard/shipment', {
                user_id:<?php echo e(auth()->user()->id); ?>,
                // address_line: document.getElementById('address_line').value,
                area: document.getElementById('area').value,
                city: document.getElementById('city').value,
                shipment_type: document.getElementById('shipment_type').value,
                business: document.getElementById('business').value,
                receiver_name: document.getElementById('receiver_name').value,
                receiver_phone: document.getElementById('receiver_phone').value,
                address: document.getElementById('address').value,
                package:document.getElementById('package').value,
                price:document.getElementById('price').value,
                note:document.getElementById('note').value,
            })
            .then(function (response) {
                //2xx
                console.log(response);
                Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: response.data.message,
                showConfirmButton: false,
                timer: 1500
                });
                document.getElementById('kt_account_profile_details_form').reset();

            })
            .catch(function (error) {
                //4xx - 5xx
                console.log(error.response.data.message);
                Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: error.response.data.message,
                showConfirmButton: false,
                timer: 1500
                });

            });
        }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ship-management\resources\views/Dashboard/user/shipment/create.blade.php ENDPATH**/ ?>