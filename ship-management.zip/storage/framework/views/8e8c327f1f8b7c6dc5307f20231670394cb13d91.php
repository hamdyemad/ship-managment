<?php $__env->startSection('title',__('site.add')); ?>

<?php $__env->startSection('page_name',__('site.shipment')); ?>

<?php $__env->startSection('pages'); ?>

<ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="<?php echo e(route('app')); ?>" class="text-muted text-hover-primary"><?php echo e(__('site.home')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="" class="text-muted text-hover-primary"><?php echo e(__('site.driver')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item text-muted">
        <a href="" class="text-muted text-hover-primary"><?php echo e(__('site.shipment')); ?></a>
    </li>
    <!--end::Item-->
    <!--begin::Item-->
    <li class="breadcrumb-item">
        <span class="bullet bg-gray-200 w-5px h-2px"></span>
    </li>
    <!--end::Item-->
    <!--begin::Item-->

    <li class="breadcrumb-item text-muted">
        <a href="" class="text-muted text-hover-primary"><?php echo e(__('site.showshipment')); ?></a>
    </li>
    <!--end::Item-->
</ul>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>

</style>

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">add the date</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="ViewPages" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                        <div class="row">
                            <label for="from" class="col-form-label"><?php echo e(__('site.date')); ?></label>
                            <div class="col-md-12">
                                <input type="date" class="form-control input-sm" id="date" name="date">
                            </div>
                            <label for="from" class="col-form-label"><?php echo e(__('site.note')); ?></label>
                            <div class="col-md-12">
                                <textarea class="form-control form-control-lg form-control-solid" name="note" id="note"
                                    style="height: 100px"></textarea>
                            </div>

                            <div class="col-md-4">
                                <button type="button" onclick="updatestatusshipment()" class="btn btn-secondary btn-sm"
                                    name="">
                                    add</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<div class="card mb-5 mb-xl-10">
    <!--begin::Card header-->
    <div class="card-header border-0 cursor-pointer" role="button" data-bs-target="#kt_account_profile_details"
        aria-expanded="true" aria-controls="kt_account_profile_details">
        <!--begin::Card title-->
        <div class="card-title m-0">
            <h3 class="fw-bolder m-0"><?php echo e(__('site.shipment')); ?></h3>
        </div>
        <!--end::Card title-->



        
        <div class="card-toolbar">
            
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo e(__('site.status')); ?>

                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" onclick="addshipment('receiver at hub',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #94c1e2"></i>&nbsp;received at hub</a>
                    </li>
                    <hr>
                    <li><a class="dropdown-item" onclick="addshipment('shipped',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #7bc1f3"></i>&nbsp;Shipped</a>
                    </li>
                    <li><a class="dropdown-item" onclick="addshipment('delivered',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #52ec7b"></i>&nbsp;Delivered</a>
                    </li>
                    <hr>
                    <li><a class="dropdown-item" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end"
                            data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo"><i
                                class="fa fa-circle" style="color: #b9bc7f"></i>&nbsp;OnHold</a>
                    </li>

                    <li><a class="dropdown-item" onclick="addshipment('no_answer',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #b9bc7f"></i>&nbsp;No Answer</a>
                    </li>
                    <hr>
                    <li><a class="dropdown-item" onclick="addshipment('rejected',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #ee83a5"></i>&nbsp;Rejected</a>
                    </li>
                    <li><a class="dropdown-item" onclick="addshipment('rejected_fees_faid',<?php echo e($shippment->id); ?>)"><i
                                class="fa fa-circle" style="color: #ee83a5"></i>&nbsp;Rejected Fees Paid</a>
                    </li>

                </ul>
            </div>

            
            <a href="<?php echo e(route('print',$shippment->id)); ?>" class="btn btn-light-primary me-3">
                <i class="fa fa-print"></i>
                <?php echo e(__('site.print')); ?>

            </a>

        </div>

    </div>
    <!--begin::Card header-->

    <!--begin::Content-->
    <div id="kt_account_profile_details" class="collapse show">
        <!--begin::Form-->
        <form id="kt_account_profile_details_form" class="form">
            <?php echo csrf_field(); ?>
            <!--begin::Card body-->
            <div class="card-body border-top p-9">


                <!--begin::shipment && business-->
                <div class="row mb-6">

                    <!--begin::Col-->
                    <div class="col-lg-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::shipment type-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.shipment_type')); ?></label>
                                <select name="shipment_type" id="shipment_type" data-placeholder="date_period"
                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0">
                                    <option value="<?php echo e($shippment->shippment_type); ?>" disabled selected>
                                        <?php echo e($shippment->shippment_type); ?>

                                    </option>
                                    

                                </select>
                            </div>
                            <!--end::shipment type-->

                            <!--begin::Col-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.business')); ?></label>
                                <input type="text" id="business" name="business"
                                    value="<?php echo e($shippment->business_referance); ?>"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::shipment && business-->

                <div class="d-flex flex-stack fs-4 py-3">
                    <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="" role="button"
                        aria-expanded="" aria-controls="kt_user_view_details">
                        <?php echo e(__('site.receiver')); ?>

                        <span class="ms-2 rotate-180">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                            <span class="svg-icon svg-icon-3">

                            </span>
                            <!--end::Svg Icon-->
                        </span>
                    </div>

                </div>

                <!--begin::name && phone-->
                <div class="row mb-6">

                    <!--begin::Col-->
                    <div class="col-lg-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::receiver name-->
                            <div class="col-lg-6 fv-row">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.name')); ?></label>
                                <input type="text" id="receiver_name" name="receiver_name"
                                    value="<?php echo e($shippment->receiver_name); ?>"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::receiver name-->

                            <!--begin::phone-->
                            <div class="col-lg-6 fv-row">
                                <label
                                    class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('site.phone')); ?></label>
                                <input type="text" id="receiver_phone" name="receiver_phone"
                                    value="<?php echo e($shippment->receiver_phone); ?>"
                                    class="form-control form-control-lg form-control-solid">
                            </div>
                            <!--end::phone-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::name && phone-->

                <!--begin::address-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        
                        <input type="text" id="address" name="address"
                            class="form-control form-control-lg form-control-solid" value="<?php echo e($shippment->address); ?>">
                        <label for="address" class="col-lg-4 col-form-label fw-bold fs-6">address</label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::address-->

                <!--begin::city && area-->
                <div class="row">

                    <!--begin::city-->
                    <div class="col-lg-6 fv-row fv-plugins-icon-container">
                        <div class="mb-5">
                            <select data-dependent="area" name="city" id="city" aria-label="Select a Timezone"
                                data-control="select2" data-placeholder="date_period"
                                class="form-select form-select-sm form-select-solid dynamic">
                                <option value="<?php echo e($shippment->city->city); ?>" disabled selected>
                                    <?php echo e($shippment->city->city); ?>

                                </option>

                            </select>
                        </div>
                    </div><br><br>
                    <!--end::city-->

                    <!--begin::area-->
                    <div class="col-lg-6 fv-row fv-plugins-icon-container">
                        <div class="mb-5">
                            <select name="area" id="area" aria-label="Select a Timezone" data-control="select2"
                                data-placeholder="date_period"
                                class="form-select form-select-sm form-select-solid dynamic">
                                <option value="<?php echo e($shippment->area->area); ?>" disabled selected>
                                    <?php echo e($shippment->area->area); ?>

                                </option>

                                
                            </select>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </div>
                    <!--end::area-->

                </div>
                <!--end::city && area-->

                <div class="d-flex flex-stack fs-4 py-3">
                    <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="" role="button"
                        aria-expanded="" aria-controls="kt_user_view_details">
                        <?php echo e(__('site.package')); ?>

                        <span class="ms-2 rotate-180">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                            <span class="svg-icon svg-icon-3">

                            </span>
                            <!--end::Svg Icon-->
                        </span>
                    </div>

                </div>

                <!--begin::package-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <textarea class="form-control form-control-lg form-control-solid" name="package" id="package"
                            style="height: 100px" aria-valuemax=""><?php echo e($shippment->package_details); ?></textarea>
                        <label for="package"><?php echo e(__('site.package')); ?></label>

                    </div>
                    <!--end::Col-->
                </div>
                <!--end::package-->

                <!--begin::price-->
                <div class="row mb-6">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <input type="number" id="price" name="price"
                            class="form-control form-control-lg form-control-solid" value="<?php echo e($shippment->price); ?>">
                        <label for="price" class="col-lg-4 col-form-label fw-bold fs-6"><?php echo e(__('site.price')); ?></label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::price-->

                <!--begin::note-->
                <div class="row mb-8">
                    <!--begin::Col-->
                    <div class="form-floating">
                        <textarea class="form-control form-control-lg form-control-solid" name="note" id="note"
                            style="height: 100px" aria-valuemax=""><?php echo e($shippment->note); ?></textarea>
                        <label for="note"><?php echo e(__('site.note')); ?></label>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::note-->

            </div>
            <!--end::Card body-->

            <!--begin::Actions-->
            
            <!--end::Actions-->
        </form>
        <!--end::Form-->
    </div>
    <!--end::Content-->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    //show city and his area in select tag
        // $(document).ready(function(){

        //     $('.dynamic').change(function(){
        //         if($(this).val() != '')
        //         {
        //         var select = $(this).attr("id");
        //         var value = $(this).val();
        //         var dependent = $(this).data('dependent');
        //         var _token = $('input[name="_token"]').val();
        //         $.ajax({
        //         url:"<?php echo e(route('dynamicdependent.fetch')); ?>",
        //         method:"POST",
        //         data:{select:select, value:value, _token:_token, dependent:dependent},
        //         success:function(result)
        //         {
        //         $('#'+ dependent).html(result);
        //         }

        //         })
        //         }
        //     });

        //         $('#city').change(function(){
        //         $('#area').val('');

        //         });

        // });

        // //update the status shipment details
        function addshipment(statusofshipment,id) {
            axios.post('/dashboard/driver/shipment/status', {
                status: statusofshipment,
                shipment_id: id,
            })
            .then(function (response) {
                //2xx
                console.log(response);
                Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: response.data.message,
                showConfirmButton: false,
                timer: 1500
                });
                // document.getElementById('kt_account_profile_details_form').reset();

            })
            .catch(function (error) {
                //4xx - 5xx
                console.log(error.response.data.message);
                Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: error.response.data.message,
                showConfirmButton: false,
                timer: 1500
                });

            });
        }

        // update status to on hold
         function updatestatusshipment() {
            axios.post('/dashboard/driver/shipment/status/onhold', {
                status: 'onhold',
                shipment_id: '<?php echo e($shippment->id); ?>',
                date:document.getElementById('date').value,
                note:document.getElementById('note').value,
            })
            .then(function (response) {
                //2xx
                console.log(response);
                Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: response.data.message,
                showConfirmButton: false,
                timer: 1500
                });


            })
            .catch(function (error) {
                //4xx - 5xx
                console.log(error.response.data.message);
                Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: error.response.data.message,
                showConfirmButton: false,
                timer: 1500
                });

            });
        }

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ship-management\resources\views/Dashboard/admin/driver/show.blade.php ENDPATH**/ ?>