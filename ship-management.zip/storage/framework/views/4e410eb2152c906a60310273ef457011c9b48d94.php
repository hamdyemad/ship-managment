<!DOCTYPE html>
<html>

<head>
    <title>Laravel 6 Search Report</title>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    
    <table class="table">
        <thead style="background-color: rgb(191, 189, 189)">
            <tr>
                <th>id</th>
                <th>date</th>
                <th>status</th>
                <th>contact name</th>
                <th>contact phone</th>
                <th>city</th>
                <th>area</th>
                <th>cash</th>
                <th>area rate</th>
                <th>cost</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PDFReports): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($PDFReports->id); ?></td>
                <td><?php echo e($PDFReports->created_at); ?></td>
                <td><?php echo e($PDFReports->shippment->status); ?></td>
                <td><?php echo e($PDFReports->shippment->receiver_name); ?></td>
                <td><?php echo e($PDFReports->shippment->receiver_phone); ?></td>
                <td><?php echo e($PDFReports->shippment->city->city); ?></td>
                <td><?php echo e($PDFReports->shippment->area->area); ?></td>
                <td><?php echo e($PDFReports->cash); ?></td>
                <?php if($PDFReports->shippment->user->special_price != 0 && $PDFReports->shippment->city->id ==
                $PDFReports->shippment->user->city_id &&
                $PDFReports->shippment->area->id == $PDFReports->shippment->user->area_id): ?>

                <td><?php echo e($PDFReports->shippment->user->special_price); ?></td>
                <?php else: ?>
                <td><?php echo e($PDFReports->shippment->area->rate); ?></td>
                <?php endif; ?>
                <td><?php echo e($PDFReports->cost); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot style="background-color: rgb(191, 189, 189)">
            <tr>
                <td colspan="9">
                    <center>Total</center>
                </td>
                <td><?php echo e($total); ?></td>
            </tr>
        </tfoot>
    </table>
</body>

</html>
<?php /**PATH C:\wamp64\www\ship-management\resources\views/dashboard/admin/accountseller/printtable.blade.php ENDPATH**/ ?>