<?php $__env->startSection('title'); ?>



<?php $__env->startSection('page_name'); ?>


<?php $__env->startSection('pages'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-primary" style="text-align: center;margin-bottom: 20px;">Scan Barcode
</h1>


<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>


<div style="width: 500px" id="reader"></div>

<form id="myFunction" method="post" action="<?php echo e(route('scan')); ?>" onsubmit="sendsometext()">
    <?php echo csrf_field(); ?>
    <input type="number" style="display: none" placeholder="" name="sometext" id="myInput">
</form>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="html5-qrcode.min.js"></script>
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
    // function onScanSuccess(decodedText, decodedResult) {
    //             console.log(`Code matched = ${decodedText}`, decodedResult);
    //             }


                function onScanFailure(error) {
                // handle scan failure, usually better to ignore and keep scanning.
                // for example:
                console.warn(`Code scan error = ${error}`);
                }

                let html5QrcodeScanner = new Html5QrcodeScanner(
                    "reader",
                    { fps: 10, qrbox: {width: 250, height: 250} },
                    /* verbose= */ false);

                // html5QrcodeScanner.render(onScanSuccess, onScanFailure);

                // ************************************************************

                    function onScanSuccess(decodedText, decodedResult) {
                    // Handle on success condition with the decoded text or result.
                    console.log(`Scan result: ${decodedText}`, decodedResult);
                        // axios.get('/dashboard/shipment/scan/' + decodedText);
                    $(function() {
                        // $("input").hide();
                       document.getElementById("myInput").value = decodedText ;
                       document.getElementById("myFunction").submit();
                    });

                    // $(function() {
                    //     axios.post('/dashboard/shipment/scan', {
                    //         firstName : document.getElementById("myInput").value ,
                    //     })
                    //     .then(function (response) {
                    //     console.log(response);
                    //     })
                    //     .catch(function (error) {
                    //     console.log(error.response.data.message);
                    //     });

                    // });


                    html5QrcodeScanner.clear();
                    // ^ this will stop the scanner (video feed) and clear the scan area.
                    }

                    html5QrcodeScanner.render(onScanSuccess);

                    // **************************************************

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ship-management\resources\views/dashboard/admin/scanner.blade.php ENDPATH**/ ?>